<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

  <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.3.min.js">
	</script>
	<script>
	$(document).ready(function(){
	    $(".mymenu").click(function(){
	    	console.log("works");
	    	$(".content").hide();
	      
	    });
	    $(".content").hide();

	     $("#ownList").click(function(){
	    	console.log("ownlist clicked");
	    	$("#ownListContent").show();
	      
	    });

      $("#wishList").click(function(){
      	console.log("wishlist clicked");
    	
    	$("#wishListContent").show();
      
   	   });

       $("#profile").click(function(){
      	console.log("profile clicked");
    	
    	$("#profileContent").show();
      
   	   });


	});
</script>
</head>
<body>

<div class="container">
	  <?php 
		$user = Auth::user();
		echo ".........authencicated User......" . $user->email;
		
  	?>





  <h2>Vlibrary</h2>
  <div class="btn-group">
	  <a href="../mybooks">  <button type="button" 
	  	class="btn btn-primary">My Book List</button>
	  </a>
	    <button type="button" class="btn btn-primary"  >Wish List</button>
	    <button type="button" class="btn btn-primary">Profile</button>
	 <a href="../addbook"><button type="button" class="btn btn-primary" >Add Book</button> </a>
	 <a href="../searchbook"><button type="button" class="btn btn-primary" >Search Book</button> </a>
	 <a href="../shownotifications"><button type="button" class="btn btn-primary" >Show Notifications</button> </a>
	 <a href="../showlendedbooks"><button type="button" class="btn btn-primary" >showlendedbooks</button> </a>
	 <a href="../reviewusers"><button type="button" class="btn btn-primary" >Review Users</button> </a>
	 


  </div>

  <div id="ownListContent" class="content">

  	
  	<h2>Owned Book List</h2>
           
	  <table class="table">
	    <thead>
	      <tr>
	        <th>BookName</th>
	        <th>Authors</th>
	        <th>Year</th>
	        <th>Catagory</th>
	        <th>Edition</th>
	        <th>Share</th>
	        <th>Availabilty</th>
	        <th>Locations</th>
	        <th>Language</th>
	        <th>Publishers</th>
	        <th>Price</th> 	        
			<th>Pages</th>



		      </tr>
		    </thead>
		    <tbody>
		      <tr>
		        <td>John</td>
		        <td>Doe</td>
		        <td>john@example.com</td>
		      </tr>
		      <tr>
		        <td>Mary</td>
		        <td>Moe</td>
		        <td>mary@example.com</td>
		      </tr>
		      <tr>
		        <td>July</td>
		        <td>Dooley</td>
		        <td>july@example.com</td>
		      </tr>
		    </tbody>
		  </table>
		  	
  </div>

  <div id="wishListContent" class="content">
  	 <p>wishlist</p>
  	
  </div>

 <div id="profileContent" class="content">
  	 <p>profile</p>
  	
  </div>



</div>

</body>
</html>
