<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Login Page</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.3.min.js"></script>


<script>	
	function onSuccess(data, status, xhr)
	{
		// with our success handler, we're just logging the data...
		console.log(data, status, xhr);
		// but you can do something with it if you like - the JSON is deserialised into an object
		console.log(String(data.value).toUpperCase());
	//	$("#div1").text("value form ajax: " + String(data.value));
		alert ("ajax successful");

	}
	$(document).ready(function() {
		var ownedBookListId;
		var borrowerId;
		// $("#myModal").modal('show');
		// $('#myModal').modal('show');
	//	$('#td1').hide();
	//	$("#curUser").hide();
		$.ajaxSetup({ headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') } });

	    $("button.baccept").click(function(event) {
	    //    alert(event.target.id);
	        userId = event.target.id ;
	        borrowerId = $(this).attr('value');
	     //   $.post('http://localhost/laravel/vlibrary/public/index.php/ajax/post', {'ownerId' : '1', 'borrowerOwnedBookListId' : ownedBookListId}, onSuccess);
	
    	//	$('#td1').show();
    	     alert(userId + "and borrerid " + borrowerId);
    	     // console.log(borrowerId);
    	     // var curUser = $('#curUser').attr('value');

    	     // if ((isNaN(ownedBookListId) || isNaN(borrowerId))) {
    	     // 	alert ("you cant see details you are not logged in");
    	     // } else {

    	     // //	alert("going to make ajax request");
    	     // 	$.post('http://localhost/laravel/vlibrary/public/index.php/ajax/postborrow', {'ownedBookListId' : ownedBookListId, 'borrowerId' : borrowerId}, onSuccess);
		
    	     // }
    	     
    	});

    	$("#lendBook").click(function(event) {
	    //    alert(event.target.id);
	      //  ownedBookListId = event.target.id ;
	     //   borrowerId = $(this).attr('value');
	     //   $.post('http://localhost/laravel/vlibrary/public/index.php/ajax/post', {'ownerId' : '1', 'borrowerOwnedBookListId' : ownedBookListId}, onSuccess);
	
    	//	$('#td1').show();
    	   //  alert(ownedBookListId + "and borrerid " + borrowerId);
    	 //    console.log(borrowerId);
    	 //    var curUser = $('#curUser').attr('value');
    	 	var point = $("#point").val();
    	 	alert ("ui: " + userId + " borrowerId: " + 
    	 		borrowerId + " point: " + point);
    	     if ((isNaN(userId) || isNaN(borrowerId) || isNaN(point))) {
    	     	alert ("you cant see details you are not logged in");
    	     } else {

    	     	
    	     	if (point > 5) {
    	     		point = 5;
    	     	}
    	     //	alert("going to make ajax request");
    	     	 $.post('http://localhost/laravel/vlibrary/public/index.php/ajax/postreview', {'userId' : userId, 'borrowerId' : borrowerId, 'point' : point}, onSuccess);
		
    	     }
    	     
    	});





//	$.post('http://localhost/laravel/vlibrary/public/index.php/ajax/post', {'ownerId' : '1', 'borrowerId' : '2'}, onSuccess);
	
	});
</script>


</head>

<body>
	<meta name="csrf-token" content="<?php echo csrf_token() ?>" />
	<div class="container">

	<h1>in show notification page </h1>


	<?php 
		var_dump($name);
		// if (Auth::check()) {
	 //  			$curUser = Auth::user();
	 //  			echo "<h1>.........authencicate......</h1>" . $curUser->email;  
	 //  			var_dump($curUser); 
	 //  			echo "<div id='curUser' value=".$curUser->id."> </div>"; 	
		// 	} else {
		// 		echo "<h1>not.............not authenticated.... </h1>";
		// 		echo "<div id='curUser' value='-1'> </div> ";
		// 	}

	 //   $borrowerFullName = $name[0]->userFullName;




	 ?>



	 	<ul class="list-group">

	 		@for($i = 0; $i < count($name); $i++)
			  <li class="list-group-item">
			  		{{$name[$i]->userFullName}} has to borrowed {{$name[$i]->bookName}} from you on .... and you reviewed him: {{$name[$i]->point}} ... 
			  		<button id="{{ $name[$i]->userId }}" 
			  		data-toggle="modal" class="baccept" data-target="#myModal"
			  		value="{{$name[$i]->borrowerId}}">Review</button>
			  		
			  </li>
			@endfor

	 		
		  <li class="list-group-item">
		  		First item  
		  		<button>Accept</button><button>Reject</button>
		  </li>
		  <li class="list-group-item">
		  		First item  
		  		<button>Accept</button><button>Reject</button>
		  </li>
		  <li class="list-group-item">
		  		First item  
		  		<button>Accept</button><button>Reject</button>
		  </li>
		</ul>



		<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>

		<!-- Modal -->
		<div id="myModal" class="modal fade" role="dialog">
		  <div class="modal-dialog">

		    <!-- Modal content-->
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h6 class="modal-title">Modal Header</h6>
		      </div>
		      <div class="modal-body">
		        <p>Review this user : </p>
		        <blockquote >
		        	Are you sure you want to send this review point??				
				</blockquote>
				Review Point <input type="text" name="point" id="point"> <br><br><br>
				<button id="lendBook">Review The User</button>
		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		      </div>
		    </div>

		  </div>
		</div>



  </div>
</body>
</html>