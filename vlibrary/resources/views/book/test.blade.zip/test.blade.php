<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>



</head>
<body>


  <h2>testing</h2>
  
  <?php
  	echo "in test controller with value " ;
   
  	

</body>
</html>
