<?php

namespace App\Model;
use DB;
use Auth;
use App\Model\SearchBook;
use App\Model\Book;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
	
    //
	public static function addToBookInfo($BookName, $Publishers, $PublishingYear,
   $PageNumbers, $Price, $Language ,$Edition) {


      //   $index = $this->getBookId($BookName);

     
          DB::insert ("INSERT INTO bookinfo 
          (BookName, Publishers, PublishingYear, PageNumbers, Price, Language, Edition)     
           VALUES (?, ?, ?, ?, ?, ?, ?)",
          [$BookName, $Publishers, $PublishingYear, $PageNumbers, $Price, $Language, 
          $Edition]);

          $lindex = DB::getPdo()->lastInsertId();
     
         \Log::info ("......last inserted id is.....");
         \Log::info ($lindex);

         return $lindex;

    
    }



//
    public static function addToAuthors($AuthorName, $bookId) {
    	
    	foreach ($AuthorName as $author) {
       

           	if (strlen($author) > 0) { 
             
                $index = Book::getAuthorId($author);
               
                if ($index < 0) 	{
                      DB::insert ('INSERT INTO authors (AuthorName) ' .
                      ' VALUES (?)', [$author]); 
                      $index = DB::getPdo()->lastInsertId();            
                }

                Book::addToBookInfoAuthors($bookId, $index);


           		}    	
                    
          }

          \Log::info ("returning from add to authros");

	
    }


    public static function addToOwnedBookList($bookId, $userId) {
         DB::insert ("INSERT INTO `ownedbooklist` (`BookId`, `UserID`, `Sharetype`, `IsAvailable`)
                    VALUES (?, ?, NULL, 1)", [$bookId, $userId]); 
                   //   $index = DB::getPdo()->lastInsertId();

         $lindex = DB::getPdo()->lastInsertId();
     
         return $lindex;



    }

    public static function insertToMessageTable($a, $b) {

   

      \Log::info("above is owner array owner id");

      $date = date('Y-m-d H:i:s');
     
       DB::insert ("INSERT INTO message (OwnedBookListId, BorrowerId, RequestTime, ResponseTime, ResponseStatus)
      VALUES (?, ?, ?, NULL, NULL)",[$a, $b, $date]);
      \Log::info("trying to insernt in messege function");

    }

    public static function insertToBorrowHistoryTable($obli, $bi) {


      \Log::info("above is owner array owner id");
     
     //   DB::insert ("INSERT INTO message (OwnedBookListId, BorrowerId, RequestTime, ResponseTime, ResponseStatus)
     //  VALUES (?, ?, NULL, NULL, NULL)",[$a, $b]);

        DB::insert ("INSERT INTO borrowhistory (OwnedBookListId, BorrowerID, BorrowDate, ReturnDate, ActualRetrunDate)
       values (?, ?, NULL, NULL, NULL)",[$obli, $bi]);

         

        \Log::info("trying to insernt in messege function");

    }



     public static function updateBorrowHistoryTable($obli, $bi) {

  
       //  DB::insert ("INSERT INTO borrowhistory (OwnedBookListId, BorrowerID, BorrowDate, ReturnDate, ActualRetrunDate)
       // values (?, ?, NULL, NULL, NULL)",[$obli, $bi]);
        $date = date('Y-m-d H:i:s');
        \Log::info("date is ");
        \Log::info($date);
         DB::table('borrowhistory')
            ->where('OwnedBookListId', $obli)
            ->where ('borrowerId', $bi)
            ->update(['ActualRetrunDate' => $date]);

        \Log::info("trying to update borrow history in messege function");

    }

     public static function updateReputaionTable($obli, $bi ,$point) {

        $collection = DB::Table('reputation')
                  ->select(                    
                     '*'
                   ) 
                   
                   ->where('userId', $obli)
                   ->where('recipientId', $bi)
                     ;           
             
          
           $notifications = $collection->get();

           if (count($notifications) == 0) {
             DB::insert ("INSERT INTO `reputation` (`UserID`, `RecipientId`, `Point`)
              VALUES (?, ?, ?)",[$obli, $bi, $point]);
      
           } else {
            DB::table('reputation')
            ->where('userId', $obli)
            ->where ('recipientId', $bi)
            ->update(['point' => $point]);

           }

           \Log::info($notifications);
        
     
         

        \Log::info("........trying to update b.....reputation");

    }




   

   public static function addToBookInfoAuthors($bookId, $authorId) {

      DB::insert ('INSERT INTO bookinfoauthors (BookId, AuthorId) ' .
              ' VALUES (?, ?)', [$bookId, $authorId]);
	
    }

   




    public static function getBookId($BookName) {


      $collection = DB::Table('bookinfo')
                  ->select(                    
                     'bookId'
                   ) 
                   
                   ->where('bookName', $BookName)
                     ;           
             
          
           $notifications = $collection->first();
           if (count($notifications) < 1) {
            return -1;
           }
    	    return $notifications->bookId;

    	
    }



    public static function getAuthorId($AuthorName) {

   

       $collection = DB::Table('authors')
                  ->select('authorId')                    
                   ->where('authorName', $AuthorName);  
           $notifications = $collection->first();
           if (count($notifications) < 1) {
            return -1;
           }
          return $notifications->authorId;

    	 \Log::info ("in the function authorName");           


    }




	

    public static function getCategory() {

       $CategoryName = DB::select(

         ' select CategoryName, categoryId ' .
           ' from category ; ') ;

          return $CategoryName;

    }



    public static function getLocations() {

    	 $LocationName = Book::getLocationName();
       //will return an array of objects
       $curUser = Auth::user();
        $userId = $curUser->id;
       $userLocations = Book::getLocationIdFromUserLocations($userId);

       $userLocationId = array();

       for ($i=0; $i < count($userLocations) ; $i++) { 
          $userLocationId[$i] = $userLocations[$i]->locationId;
       }

       $LocationName2 = array();

       for ($i=0; $i < count($LocationName) ; $i++) { 
           if (in_array($LocationName[$i]->locationId, $userLocationId)) {
               $temp = array($LocationName[$i]->LocationName, '1'); 
           } else {
              $temp = array($LocationName[$i]->LocationName, '0'); 

           }

           $LocationName2[$i] = $temp;
       }

  //     \Log::info($LocationName2);
   //    \Log::info("..........returning complex cat name");
        



          return $LocationName2;

    }

    public static function getLocationName() {

       $LocationName = DB::select(

         ' select LocationName, locationId ' .
           ' from Locations ; ') ;
          return $LocationName;

    }



    //returns a array of ownedbooklistId
    public static function getOwnedBookListId($userId) {

       $collection = DB::Table('ownedbooklist')
                  ->select('ownedbooklistId')                    
                   ->where('userId', $userId);  
        $notifications = $collection->get();

        $ownedbooklistId = array();
        for ($i=0; $i < count($notifications); $i++) { 
            $ownedbooklistId[$i] = $notifications[$i]->ownedbooklistId;
        }

        //returning array not objects;
        return $ownedbooklistId;
           


    }


    // takes array as input

    public static function addToBookInfoCategory($bookId, $CategoryName) {

        $query = DB::table('category')
                 ->select('categoryId');

        for ($i=0; $i < count($CategoryName); $i++) { 
             if ($i == 0) {
                $query->where('CategoryName', $CategoryName[$i]);
             } else {
                 $query->orwhere('CategoryName', $CategoryName[$i]);
             }
        }

        $categoryId = $query->get();

        \Log::info($categoryId);
        \Log::info("......categoryIds.");

        for ($i=0; $i < count($categoryId); $i++) { 
           DB::insert("INSERT INTO `bookinfocategory` (`BookId`, `CategoryId`)
           VALUES (?, ?);",[$bookId, $categoryId[$i]->categoryId ]);

        }


    }



     public static function addToOwnedBookListLocations($ownedBookListId, $LocationName) {

        $query = DB::table('Locations')
                 ->select('locationId');

        for ($i=0; $i < count($LocationName); $i++) { 
             if ($i == 0) {
                $query->where('LocationName', $LocationName[$i]);
             } else {
                 $query->orwhere('LocationName', $LocationName[$i]);
             }
        }

        $locationId = $query->get();

        \Log::info($locationId);
        \Log::info("......categoryIds.");

        for ($i=0; $i < count($locationId); $i++) { 
           DB::insert("INSERT INTO `ownedbooklocations` (`OwnedBookListId`, `LocationId`)
            VALUES (?, ?);",[$ownedBookListId, $locationId[$i]->locationId ]);

        }


    }


    public static function addToCategory($categoryName) {

        DB::insert("INSERT INTO `category` (`CategoryName`)
        VALUES (?);", [$categoryName]);

    }

     public static function addToLocations($LocationName) {

        DB::insert("INSERT INTO `locations` (`LocationName`)
        VALUES (?);", [$LocationName]);

    }

//$locationname is array of string locationName
     public static function addToUserLocations($userId, $LocationName) {

        $query = DB::table('Locations')
                 ->select('locationId');

        for ($i=0; $i < count($LocationName); $i++) { 
             if ($i == 0) {
                $query->where('LocationName', $LocationName[$i]);
             } else {
                 $query->orwhere('LocationName', $LocationName[$i]);
             }
        }

        $locationId = $query->get();
        // location id is array of locationId objects

     //   \Log::info($locationId);
     //   \Log::info("......categoryIds.");

        for ($i=0; $i < count($locationId); $i++) { 
           DB::insert("INSERT INTO `userlocations` (`UserID`, `LocationId`)
          VALUES (?, ?);",[$userId, $locationId[$i]->locationId ]);

        }


    }

    
    public static function deleteFromUserLocations($userId) {
       DB::table('userLocations')->where('userId', '=', $userId)->delete();
       
    }


    public static function getLocationIdFromUserLocations($userId) {

        $query = DB::table('userLocations')
                 ->select('locationId')
                 ->where('userId', $userId);

        $data = $query->get();

        return $data;


    }







    






	

}
