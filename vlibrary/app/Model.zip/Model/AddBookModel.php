<?php

namespace App\Model;
use DB;
use Auth;
use App\Model\SearchBook;
use App\Model\Book;
use App\Model\AddBookModel;
use App\Model\GetBookModel;
use Illuminate\Database\Eloquent\Model;

class AddBookModel extends Model
{
	
}