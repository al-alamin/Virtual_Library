<?php

namespace App\Model;
use DB;

use Illuminate\Database\Eloquent\Model;

class SearchBook extends Model
{

    public static function getBookNameOwnedBooklistId($bookName) {
     //  \Log::info("........in searchbook model ");

        $name = DB::Table('bookinfo')
                ->select('bookinfo.BookName', 
                  'bookinfo.bookId', 'ownedBookList.ownedBookListId', 'ownedBookList.userId')                
                ->join('ownedBookList', 'bookinfo.bookid', '=',
                 'ownedBookList.bookid')      
                 ->where('bookinfo.bookName', 'like', '%'. $bookName . '%')       
                ->get();

        return $name;


    }

    public static function getBookInformation($ownedBookListId) {
     $collection = DB::Table('ownedBookList')
                      ->select(
                        'ownedBookList.ownedBookListId',
                        'bookinfo.bookName', 'bookinfo.edition', 'bookinfo.publishers',
                        'bookinfo.Language' , 'BOOKINFO.publishingYear'
                        
                        )
                      ->join('bookinfo', 'bookinfo.bookid', '=', 'ownedBookList.bookid');
                     

          for ($i = 0; $i < count($ownedBookListId); $i++) {
              if($i == 0) {
                   $collection->where('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
              } else {
               $collection->orwhere('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
              }
          }  

          $collection = $collection->orderby('ownedBookList.ownedBookListId');
           

            
          $bookInformation = $collection->get();

          return $bookInformation;


    }

   public static function getAuthorInformation($ownedBookListId) {
     $collection = DB::Table('ownedBookList')
                      ->select(
                        'ownedBookList.ownedBookListId',
                         'ownedBookList.bookId',
                         
                        'authors.authorName'
                        )
                      ->join('BOOKINFOAUTHORS', 'ownedBookList.bookid', '=', 'BOOKINFOAUTHORS.bookid')
                      ->join('AUTHORS','authors.authorId', '=', 'BOOKINFOAUTHORS.AUTHORID');
                      
      for ($i = 0; $i < count($ownedBookListId); $i++) {
              if($i == 0) {
                   $collection->where('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
              } else {
               $collection->orwhere('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
              }
          }  
          $collection = $collection->orderby('ownedBookList.ownedBookListId');
          $authorInformation = $collection->get();
          return $authorInformation;



   }


    public static function getCategoryInformation($ownedBookListId) {
     $collection = DB::Table('ownedBookList')
                      ->select(
                        'ownedBookList.ownedBookListId',
                         'ownedBookList.bookId',
                         
                        'category.categoryName'
                        )
                      ->join('BOOKINFOCATEGORY', 'ownedBookList.bookid', '=', 'BOOKINFOCATEGORY.bookid')
                      ->join('CATEGORY', 'CATEGORY.CATEGORYID', '=', 'BOOKINFOCATEGORY.CATEGORYID');
                      
     for ($i = 0; $i < count($ownedBookListId); $i++) {
              if($i == 0) {
                   $collection->where('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
              } else {
               $collection->orwhere('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
              }
          }  
         
                      
           $collection = $collection->orderby('ownedBookList.ownedBookListId');
          $categoryInformation = $collection->get();
          return $categoryInformation;



   }


    public static function getUserInformation($ownedBookListId) {
     $collection = DB::Table('ownedBookList')
                  ->select( 'ownedBookList.ownedBookListId',
                   'ownedBookList.bookId',
                   'user.id',   'ownedBookList.isAvailable', 'user.email',                 
                    'user.userFullName', 'user.phoneNo', 'user.mobileNo')
                   ->join('user', 'user.Id', '=', 'ownedBookList.userId')
                   ;
                      
            for ($i = 0; $i < count($ownedBookListId); $i++) {
            if($i == 0) {
                 $collection->where('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
            } else{
             $collection->orwhere('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
            }
           }  
            $collection = $collection->orderby('ownedBookList.ownedBookListId');
           $userInformation = $collection->get();

           return $userInformation;



   }



    public static function getbookLocationInformation($ownedBookListId) {
     $collection = DB::Table('ownedBooklocations')
                  ->select(                    
                    'ownedBooklocations.ownedBookListId','Locations.LocationName'                                       
                   )                   
                   ->join('locations', 'locations.locationId',
                    '=', 'ownedbooklocations.locationId')
                   ->orderby('ownedBooklocations.ownedBookListId');

                      
            for ($i = 0; $i < count($ownedBookListId); $i++) {
            if($i == 0) {
                 $collection->where('ownedBooklocations.ownedBookListId', $ownedBookListId[$i]);
              } else {
               $collection->orwhere('ownedBooklocations.ownedBookListId', $ownedBookListId[$i]);
              }
             }  

              $collection = $collection->orderby('ownedBooklocations.ownedBookListId');
           $bookLocationInformation = $collection->get();

           return $bookLocationInformation;




   }



   



   






	
   












 






	

}












 // $collection = DB::Table('ownedBookList')
        //               ->select('bookinfo.bookName', 'bookinfo.edition', 'bookinfo.publishers',
        //                 'bookinfo.Language', 'ownedBookList.isAvailable',
        //                 'authors.authorName', 'CATEGORY.CATEGORYNAME', 
        //                 'user.userFullName', 'user.phoneNo', 'user.mobileNo')
        //               ->leftjoin('BOOKINFOAUTHORS', 'ownedBookList.bookid', '=', 'BOOKINFOAUTHORS.bookid')
        //               ->leftjoin('AUTHORS','authors.authorId', '=', 'BOOKINFOAUTHORS.AUTHORID')
        //               ->join('bookinfo', 'bookinfo.bookid', '=', 'ownedBookList.bookid')
        //               ->leftjoin('BOOKINFOCATEGORY', 'BOOKINFOCATEGORY.bookId', '=', 'BOOKINFO.bookId')
        //               ->leftjoin('CATEGORY', 'BOOKINFOCATEGORY.CATEGORYID', '=', 'CATEGORY.CATEGORYID')
        //               ->join('user', 'user.Id', '=', 'ownedBookList.userId')

        //               ->where('ownedBookList.ownedBookListId', $ownedBookListId[0]);
        //  for ($i = 0; $i < count($ownedBookListId); $i++) {
        //     if($i == 0) {
        //          $collection->where('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
        //     }
        //      $collection->orwhere('ownedBookList.ownedBookListId', $ownedBookListId[$i]);
        //    }  

